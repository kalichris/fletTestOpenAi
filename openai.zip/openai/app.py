import flet as ft 
print(1)
from flet import *

import Pages.login


print("loading")
# class MainApp(UserControl):
#     def __init__(self):
#         super().__init__()
#         pass 
def main(page:ft.Page):
    print("Starting.....")
    def fn_views(page):
        return {
            "/login":View(
                route="/",
                controls=[
                    MainLogin(page)
                ]
            ),"/openai":View(
                route="/openai",
                controls=[
                    MainChat(page)
                ]
            )

        }
    print("Go...")
    page.go("/login")
    page.views.append(fn_views(page))
   # page.update() 
    print(page.pwa)
print("1")
ft.app(target=main)
print(2)